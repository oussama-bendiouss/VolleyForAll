package com.example.projetcodingweeks.others;

public interface NextFunction {
    void next();
}
