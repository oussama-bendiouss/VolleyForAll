package com.example.projetcodingweeks.others;

public class NotImplementedException extends Exception {
    public NotImplementedException(String desc) {
        super(desc);
    }
    public NotImplementedException() {
        this("Not implemented yet");
    }
}
