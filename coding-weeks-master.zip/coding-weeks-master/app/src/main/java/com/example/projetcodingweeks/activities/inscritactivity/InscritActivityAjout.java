package com.example.projetcodingweeks.activities.inscritactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projetcodingweeks.objects.CDate;
import com.example.projetcodingweeks.others.DBM;
import com.example.projetcodingweeks.others.GlobalVar;
import com.example.projetcodingweeks.objects.Inscrit;
import com.example.projetcodingweeks.activities.MenuActivity;
import com.example.projetcodingweeks.R;

import java.text.ParseException;

public class InscritActivityAjout extends AppCompatActivity {

    private Inscrit inscriptionUtilisateur;

    private Button HoraireDebut;
    private Button HoraireFin;
    private CheckBox hasBall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscrit_ajout);

        HoraireDebut = findViewById(R.id.buttonHoraireDebut);
        HoraireFin = findViewById(R.id.buttonHoraireFin);
        hasBall = findViewById(R.id.hasBall);

        inscriptionUtilisateur = new Inscrit(
                new CDate(CDate.ONE_HOUR),
                new CDate(CDate.TWO_HOUR),
                "rien",
                GlobalVar.CurrentLoggedUser
        );

        HoraireDebut.setText(inscriptionUtilisateur.getHoraireDebut().getDate());
        HoraireFin.setText(inscriptionUtilisateur.getHoraireFin().getDate());
        updateDateDisplay();

    }

    public void modifyDeb(View view) {
        modifyDateAndTime(inscriptionUtilisateur.getHoraireDebut());
    }

    public void modifyFin(View view) {
        modifyDateAndTime(inscriptionUtilisateur.getHoraireFin());
    }

    private void modifyDateAndTime(CDate cdate) {
        DatePickerDialog.OnDateSetListener dateListener = (v1, year, month, day) -> {
            String newDate = day + "/" + month + "/" + year;


            TimePickerDialog.OnTimeSetListener timeListener = (v2, hour, min) -> {
                String newTime = hour + ":" + min + ":00";
                try {
                    cdate.setDate(newTime + " " + newDate);
                    DBM.InscritTable.update(inscriptionUtilisateur, response -> {
                        if (DBM.isSuccess(response)) {
                            updateDateDisplay();
                            Toast.makeText(this, "La mise a jour a bien été faite.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Une erreur est apparue lors de la mise à jour.", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (ParseException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Erreur lors de l'écriture.", Toast.LENGTH_SHORT).show();
                }
            };
            TimePickerDialog questionTime = new TimePickerDialog(this, timeListener, cdate.getHour(), cdate.getMin(), true);
            questionTime.show();

        };
        DatePickerDialog questionDate = new DatePickerDialog(this, dateListener, cdate.getYear(), cdate.getMonth(), cdate.getDay());
        questionDate.show();
    }

    private void updateDateDisplay() {
        HoraireDebut.setText(inscriptionUtilisateur.getHoraireDebut().getDate());
        HoraireFin.setText(inscriptionUtilisateur.getHoraireFin().getDate());
    }


    public void cliqueRetour(View view) {
        PassMenu();
    }

    public void clickValidate(View view) {
        if (hasBall.isChecked())
            inscriptionUtilisateur.setMateriel("Ballon");

        // les dates sont déjà ajoutée à inscriptionUtilisateur

        //on rajoute les horaires et le materiel dans la base de données
        DBM.InscritTable.update(inscriptionUtilisateur, this::onResponseAdd);
    }

    private void onResponseAdd(String response) {
        if (DBM.isSuccess(response)) {
            Toast.makeText(this, "L'inscription a été ajoutée avec succès.", Toast.LENGTH_SHORT).show();
            // On ferme l'activité après synchronisation pour éviter les ajout intempestifs
            DBM.syncDBAndExecute(() -> finish());
        } else {
            Toast.makeText(this, "Une erreur est apparue lors de la création de l'inscription.", Toast.LENGTH_SHORT).show();
        }
    }

    private void PassMenu() {
        Intent versMenu = new Intent();
        versMenu.setClass(getApplicationContext(), MenuActivity.class);
        startActivity(versMenu);
    }

}
