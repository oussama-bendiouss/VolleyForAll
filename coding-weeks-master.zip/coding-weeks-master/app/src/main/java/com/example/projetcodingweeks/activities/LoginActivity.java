package com.example.projetcodingweeks.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.projetcodingweeks.others.NextFunction;
import com.example.projetcodingweeks.objects.Personne;
import com.example.projetcodingweeks.R;
import com.example.projetcodingweeks.others.DBM;
import com.example.projetcodingweeks.others.GlobalVar;

public class LoginActivity extends AppCompatActivity {
    private EditText editTextEtunum;
    private Button buttonValider;
    private Button buttonCreerCompte;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Récupération des liens
        editTextEtunum = findViewById(R.id.editTextEtunum);
        buttonValider = findViewById(R.id.buttonV);
        buttonCreerCompte = findViewById(R.id.buttonC);
    }

    public void Valider(View view) {
        //on vérifie que l'etunum est bien dans la base de données, si c'est le cas on passe à
        //MenuActivity
        DBM.syncDBAndExecute(new NextFunction() {
            @Override
            public void next() {
                parcourirBDD(Integer.parseInt(editTextEtunum.getText().toString()));
            }
        });
    }

    public void NewCompte(View view) {
        //Pour passer à CreerCompte
        Intent versCreerCompte = new Intent();
        versCreerCompte.setClass(getApplicationContext(), CreerCompteActivity.class);
        startActivity(versCreerCompte);
    }


    public void parcourirBDD(int etunum) {
        for (Personne personne : GlobalVar.AllPersonne) {
            //si l'etunum est le même que celui qui a été rentré, alors le compte est déjà existant et on peut passer à MenuActivity
            if (personne.getEtunum() == etunum) {
                //on rempli GlobalVar pour pouvoir utiliser ces données dans toutes les autres activités
                GlobalVar.CurrentLoggedUser = personne;
                PassMenu();
                break;
            }
        }

    }

    //pour passer à MenuActivity
    private void PassMenu() {
        Intent versMenu = new Intent();
        versMenu.setClass(getApplicationContext(), MenuActivity.class);
        startActivity(versMenu);
        finish();
    }
}
