package com.example.projetcodingweeks.others;

import com.example.projetcodingweeks.objects.Inscrit;
import com.example.projetcodingweeks.objects.Personne;

import java.util.Set;

public enum GlobalVar {
    ; // enum vide

    public static Personne CurrentLoggedUser;
    public static Set<Personne> AllPersonne;
    public static Set<Inscrit> AllInscrit;

}
