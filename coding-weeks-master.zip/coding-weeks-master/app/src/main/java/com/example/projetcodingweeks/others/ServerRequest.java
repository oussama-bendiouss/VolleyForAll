package com.example.projetcodingweeks.others;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Map;

public class ServerRequest {

    public static final String url_test = "https://api.chucknorris.io/jokes/random";

    private final Context main;
    /**
     *          Usage :
     *  ServerRequest sr = new ServerRequest(this);
     *     sr.request(new ServerCallBack() {
     *     @Override
     *     public void onResponse(String response) {
     *         //do stuff with response here
     *     }
     *  });
     */
    public ServerRequest(Context main) {
        this.main = main;
    }

    public void requestGet(final String url, ServerCallBack callBack) {
        RequestQueue requestQueue = Volley.newRequestQueue(main);
        Response.Listener<String> responseListener = callBack::onResponse;
        /*
            Equivalent to :
        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                callBack.onResponse(response);
            }
        };
         */
        Response.ErrorListener errorResponseListener = Throwable::printStackTrace;
        /*
            Equivalent to :
        Response.ErrorListener errorResponseListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
         */
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, responseListener, errorResponseListener);
        requestQueue.add(stringRequest);
    }
    public void requestGetTest(ServerCallBack callBack) {
        requestGet(url_test, callBack);
    }

    public void requestPost(final String url, Map<String, String> params, ServerCallBack callBack) {
        RequestQueue requestQueue = Volley.newRequestQueue(main);
        Response.Listener<String> responseListener = callBack::onResponse;
        Response.ErrorListener errorResponseListener = Throwable::printStackTrace;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, responseListener, errorResponseListener) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}
