package com.example.projetcodingweeks.objects;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CDate implements Serializable {

    private Date date;
    // modifying standardDateFormat implies modification in the database and in CDate methods
    public static final String standardDateFormat = "HH:mm:ss dd/MM/yyyy";

    public static final int NOW = 0;
    public static final int ONE_HOUR = 1;
    public static final int TWO_HOUR = 2;

    public CDate(String dateStr, String dateformat) throws ParseException {
        DateFormat df = new SimpleDateFormat(dateformat);
        this.date = df.parse(dateStr);
    }

    public CDate(String dateStr) throws ParseException {
        this(dateStr, standardDateFormat);
    }

    public CDate(int nbHourFromNow) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, nbHourFromNow);
        date = cal.getTime();
    }

    public String getDate(String dateformat) {
        DateFormat df = new SimpleDateFormat(dateformat);
        return df.format(date);
    }

    public String getDate() {
        return getDate(standardDateFormat);
    }

    public Date getDateObject() {
        return date;
    }

    public void setDate(String newDate, String dateformat) throws ParseException {
        DateFormat df = new SimpleDateFormat(dateformat);
        date = df.parse(newDate);
    }

    public void setDate(String newDate) throws ParseException {
        setDate(newDate, standardDateFormat);
    }


    public int getYear() {
        String str = getDate();
        return Integer.parseInt(str.split(" ")[1].split("/")[2]);
    }
    public int getMonth() {
        String str = getDate();
        return Integer.parseInt(str.split(" ")[1].split("/")[1]);
    }
    public int getDay() {
        String str = getDate();
        return Integer.parseInt(str.split(" ")[1].split("/")[0]);
    }

    public int getHour() {
        String str = getDate();
        return Integer.parseInt(str.split(" ")[0].split(":")[0]);
    }
    public int getMin() {
        String str = getDate();
        return Integer.parseInt(str.split(" ")[0].split(":")[1]);
    }
    public int getSec() {
        String str = getDate();
        return Integer.parseInt(str.split(" ")[0].split(":")[2]);
    }
}
