package com.example.projetcodingweeks.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projetcodingweeks.others.GlobalVar;
import com.example.projetcodingweeks.others.NextFunction;
import com.example.projetcodingweeks.objects.Personne;
import com.example.projetcodingweeks.R;
import com.example.projetcodingweeks.others.ServerCallBack;
import com.example.projetcodingweeks.others.DBM;

public class CreerCompteActivity extends AppCompatActivity {
    private EditText editTextPrenom;
    private EditText editTextNom;
    private EditText editTextEtunum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creer_compte);

        //récupération des liens
        editTextPrenom = findViewById(R.id.editTextPrenom);
        editTextNom = findViewById(R.id.editTextNom);
        editTextEtunum = findViewById(R.id.editTextEtunum);
    }



    public void CreerClique(View view) {
        //on met à jour la base de données et on crée le compte que s'il n'existe pas encore
        DBM.syncDBAndExecute(new NextFunction() {
            @Override
            public void next() {
                parcourirBDD(Integer.parseInt(editTextEtunum.getText().toString()));
            }
        });
    }

    //pour retourner à l'activité précédente
    public void BackClique(View view) {
        PassLogin();
    }



    public void parcourirBDD (int etunum) {
        boolean found = false;
        for (Personne personne : GlobalVar.AllPersonne) {
            //si l'etunum est le même que celui qui a été rentré, alors le compte est déjà existant
            if (personne.getEtunum() == etunum) {
                found = true;
                Toast.makeText(this, "Ce compte existe déjà.", Toast.LENGTH_SHORT).show();
                break;
            }
        }

        if (!found) {
            //on a tout parcouru et l'utilisateur n'existe pas dans la base de données, on peut donc créer une nouvelle instance Personne dans la base de données.
            Personne utilisateur = new Personne(editTextNom.getText().toString(), editTextPrenom.getText().toString(), etunum, "Non renseigné", "Non renseigné");
            Log.i("CreationUtilisateur", utilisateur.getNom() +
                    " / " + utilisateur.getPrenom() +
                    " / " + utilisateur.getEtunum() +
                    " / " + utilisateur.getTel() +
                    " / " + utilisateur.getEmail());
            //on rempli GlobalVar pour pouvoir utiliser ces données dans toutes les autres activités
            DBM.PersonneTable.create(utilisateur, new ServerCallBack() {
                @Override
                public void onResponse(String response) {
                    if (DBM.isSuccess(response)) {
                        // L'utilisateur est ajouté dans la BDD distante, on l'ajoute aux GlobalVars et on passe à MenuActivity
                        Toast.makeText(CreerCompteActivity.this, "Votre compte a été créé.", Toast.LENGTH_SHORT).show();
                        GlobalVar.CurrentLoggedUser = utilisateur;
                        GlobalVar.AllPersonne.add(utilisateur);
                        PassMenu();
                    } else {
                        Toast.makeText(CreerCompteActivity.this, "Erreur lors de la création.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            Toast.makeText(this, "Cet etunum est déjà renseigné.", Toast.LENGTH_SHORT).show();
        }

    }

    //pour passer à MenuActivity
    private void PassMenu() {
        Intent versMenu = new Intent();
        versMenu.setClass(getApplicationContext(), MenuActivity.class);
        startActivity(versMenu);
        finish();
    }

    private void PassLogin() {
        Intent versLogin = new Intent();
        versLogin.setClass(getApplicationContext(), LoginActivity.class);
        startActivity(versLogin);
    }
}