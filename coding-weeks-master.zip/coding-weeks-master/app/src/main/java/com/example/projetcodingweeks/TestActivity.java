package com.example.projetcodingweeks;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TestActivity extends AppCompatActivity {

    private TextView date;
    private TextView time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        date = findViewById(R.id.textDate);
        time = findViewById(R.id.textTime);

    }

    public void setTime(View view) {
        TimePickerDialog.OnTimeSetListener listener = (v, hour, min) -> {
            String newTime = hour + ":" + min + ":00";
            time.setText(newTime);
        };
        TimePickerDialog question = new TimePickerDialog(this, listener, 12, 0, true);
        question.show();
    }

    public void setDate(View view) {
        DatePickerDialog.OnDateSetListener listener = (v, year, month, day) -> {
            String newDate = day + "/" + month + "/" + year;
            date.setText(newDate);
        };
        DatePickerDialog question = new DatePickerDialog(this, listener, 2020, 01, 01);
        question.show();
    }
}