package com.example.projetcodingweeks.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.solver.state.State;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.projetcodingweeks.R;
import com.example.projetcodingweeks.activities.inscritactivity.InscritActivityModifier;
import com.example.projetcodingweeks.objects.Inscrit;
import com.example.projetcodingweeks.others.GlobalVar;

import static com.example.projetcodingweeks.others.GlobalVar.CurrentLoggedUser;

public class MesInscriptionsActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mes_inscriptions);


        LinearLayout INS = findViewById(R.id.INSCRIPTION);
        LinearLayout.LayoutParams templateContainerParams = (LinearLayout.LayoutParams) findViewById(R.id.templateContainer).getLayoutParams();
        ConstraintLayout.LayoutParams templateTextParams = (ConstraintLayout.LayoutParams) findViewById(R.id.templateTextView).getLayoutParams();
        ConstraintLayout.LayoutParams templateButtonParams = (ConstraintLayout.LayoutParams) findViewById(R.id.templateButton).getLayoutParams();
        INS.removeView(findViewById(R.id.templateContainer));

        for (Inscrit inscrit: GlobalVar.AllInscrit) {
            if (inscrit.getPersonneConcerne().getEtunum() == CurrentLoggedUser.getEtunum()) {

                // Creates a container
                ConstraintLayout container = new ConstraintLayout(this);
                LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                containerParams.bottomMargin = templateContainerParams.bottomMargin;
                containerParams.topMargin = templateContainerParams.topMargin;

                INS.addView(container);

                // Set up the TextView showing details of the inscrit object
                TextView textView = new TextView(this);
                textView.setText(inscrit.getAffichage());
                // Set up constraints
                ConstraintLayout.LayoutParams textParams = new ConstraintLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                textParams.topToTop = templateTextParams.topToTop;
                textParams.bottomToBottom = templateTextParams.bottomToBottom;
                textParams.leftToLeft = templateTextParams.leftToLeft;
                textParams.bottomMargin = templateTextParams.bottomMargin;
                textParams.topMargin = templateTextParams.topMargin;
                // Finally add the TextView
                container.addView(textView, -1, textParams);

                // Create and set up a button for modifications
                Button modifierButton = new Button(this);
                modifierButton.setText("MODIFIER");
                modifierButton.setOnClickListener(view -> PassInscriptionModifier(inscrit));
                // Set up constraints
                ConstraintLayout.LayoutParams buttonParams = new ConstraintLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                );
                buttonParams.rightToRight = templateButtonParams.rightToRight;
                buttonParams.topToTop = templateButtonParams.topToTop;
                buttonParams.bottomToBottom = templateButtonParams.bottomToBottom;
                // Finally add the button
                container.addView(modifierButton, -1, buttonParams);

            }
        }
    }

    public void onCliqueRetour(View view) {
        PassMenu();
    }

    private void PassInscriptionModifier(Inscrit inscrit) {
        Intent versInsciptionModifier = new Intent();
        versInsciptionModifier.setClass(getApplicationContext(), InscritActivityModifier.class);
        versInsciptionModifier.putExtra("Inscription", inscrit);
        startActivity(versInsciptionModifier);
    }

    private void PassMenu() {
        Intent versMenu = new Intent();
        versMenu.setClass(getApplicationContext(), MenuActivity.class);
        startActivity(versMenu);
    }

}