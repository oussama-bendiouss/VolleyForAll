package com.example.projetcodingweeks.objects;

import java.io.Serializable;

public class Personne implements Serializable {
    private String nom;
    private String prenom;
    private int etunum;
    private String tel;
    private String email;

    public Personne(String nom,String prenom,int etunum,String tel,String email){
        this.nom = nom;
        this.prenom = prenom;
        this.etunum = etunum;
        this.tel = tel;
        this.email = email;
    }

    public String getNom(){return nom;}

    public void setNom(java.lang.String nom) {
        this.nom = nom;
    }

    public String getPrenom(){return prenom;}

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getEtunum(){return etunum;}

    public void setEtunum(int etunum) {
        this.etunum = etunum;
    }

    public String getTel(){return tel;}

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail(){return email;}

    public void setEmail(String email) {
        this.email = email;
    }
}
