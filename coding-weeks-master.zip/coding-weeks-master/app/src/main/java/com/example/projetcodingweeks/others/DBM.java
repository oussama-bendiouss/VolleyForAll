package com.example.projetcodingweeks.others;

import android.util.Log;

import com.example.projetcodingweeks.objects.Inscrit;
import com.example.projetcodingweeks.objects.Personne;
import com.example.projetcodingweeks.objects.CDate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.InvalidKeyException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Ensemble de fonctions pour discuter avec la BDD
 * @Syntax DBM."nomDeLaTable"Table."insctruction"(...)
 *         parseGet(...) et parseGetAll(...) permettent de transformer la
 *         réponse du serveur en objet Inscrit ou Personne
 */
public enum DBM {
    ; // empty enum

    public enum InscritTable {
        ;
        public static ServerRequest sr;

        public static void getAll(ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/get_all_inscrit.php";
            sr.requestGet(url, callBack::onResponse);
        }
        public static void getAll(ServerCallBack callBack) {
            getAll(sr, callBack);
        }
        public static Set<Inscrit> parseGetAll(String response, Map<Integer, Personne> allPersons) {
            Set<Inscrit> set = new HashSet<Inscrit>();
            if (!isSuccess(response)) return set;
            try {
                JSONObject jsonResponse = new JSONObject(response);
                JSONArray jsonPersons = jsonResponse.getJSONArray("products");
                for (int index = 0; index < jsonPersons.length(); index++) {

                    JSONObject jsonPerson = jsonPersons.getJSONObject(index);
                    int etunum = jsonPerson.getInt("etunum");

                    if (allPersons.get(etunum) == null) Log.e("DBM", "Person of etunum " + index + " does not appear in allPersons local var");

                    set.add(DBM.toInscrit(jsonPerson, allPersons.get(etunum)));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return set;
        }

        public static void create(Inscrit i, ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/create_inscrit.php";
            Map<String, String> params = new HashMap<>();

            params.put("etunum", "" + i.getPersonneConcerne().getEtunum());
            params.put("horaireDeb", i.getHoraireDebut().getDate());
            params.put("horaireFin", i.getHoraireFin().getDate());
            params.put("materiel", i.getMateriel());

            sr.requestPost(url, params, callBack);
        }
        public static void create(Inscrit i, ServerCallBack callBack) {
            create(i, sr, callBack);
        }

        public static void delete(int inscrit_id, ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/delete_inscrit.php";
            Map<String, String> params = new HashMap<>();

            params.put("inscrit_id", "" + inscrit_id);

            sr.requestPost(url, params, callBack);
        }
        public static void delete(int inscrit_id, ServerCallBack callBack) {
            delete(inscrit_id, sr, callBack);
        }

        public static void get(int inscrit_id, ServerRequest sr, ServerCallBack callBack) throws NotImplementedException {
            String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/get_inscrit_details.php";
            url = url + "?inscrit_id=" + inscrit_id;
            sr.requestGet(url, callBack);
        }
        public static Inscrit parseGet(String response, Personne pers) {
            if (!isSuccess(response)) return null;
            try {
                JSONObject jsonResponse = new JSONObject(response);
                JSONObject jsonInscrit = jsonResponse.getJSONArray("product").getJSONObject(0);
                return toInscrit(jsonInscrit, pers);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        public static void get(int inscrit_id, ServerCallBack callBack) throws NotImplementedException {
            get(inscrit_id, sr, callBack);
        }

        public static void update(Inscrit i, ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/update_inscrit.php";
            Map<String, String> params = new HashMap<>();

            params.put("inscrit_id", "" + i.getInscrit_id());
            params.put("etunum", "" + i.getPersonneConcerne().getEtunum());
            params.put("horaireDeb", i.getHoraireDebut().getDate());
            params.put("horaireFin", i.getHoraireFin().getDate());
            params.put("materiel", i.getMateriel());

            sr.requestPost(url, params, callBack);
        }
        public static void update(Inscrit i, ServerCallBack callBack) {
            update(i, sr, callBack);
        }
    }

    public enum PersonneTable {
        ; // empty enum
        public static ServerRequest sr;

        public static void getAll(ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/get_all_personne.php";
            sr.requestGet(url, callBack::onResponse);
        }
        public static void getAll(ServerCallBack callBack) {
            getAll(sr, callBack);
        }
        public static Set<Personne> parseGetAll(String response) {
            Set<Personne> set = new HashSet<Personne>();
            if (!isSuccess(response)) return set;
            try {
                JSONObject jsonResponse = new JSONObject(response);
                JSONArray jsonPersons = jsonResponse.getJSONArray("products");
                for (int index = 0; index < jsonPersons.length(); index++){
                    set.add(DBM.toPersonne(jsonPersons.getJSONObject(index)));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return set;
        }

        public static void create(Personne pers, ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/create_personne.php";
            Map<String, String> params = new HashMap<>();

            params.put("etunum", "" + pers.getEtunum());
            params.put("nom", "" + pers.getNom());
            params.put("prenom", pers.getPrenom());
            params.put("phoneNb", pers.getTel());
            params.put("email", pers.getEmail());

            sr.requestPost(url, params, callBack);
        }
        public static void create(Personne pers, ServerCallBack callBack) {
            create(pers, sr, callBack);
        }

        public static void delete(int etunum, ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/delete_personne.php";
            Map<String, String> params = new HashMap<>();

            params.put("etunum", "" + etunum);

            sr.requestPost(url, params, callBack);
        }
        public static void delete(int etunum, ServerCallBack callBack) {
            delete(etunum, sr, callBack);
        }

        public static void get(int etunum, ServerRequest sr, ServerCallBack callBack) {
            String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/get_personne_details.php";
            url = url + "?etunum=" + etunum;

            sr.requestGet(url, callBack);
        }
        public static void get(int etunum, ServerCallBack callBack) {
            get(etunum, sr, callBack);
        }
        public static Personne parseGet(String response) {
            if (!isSuccess(response)) return null;
            try {
                JSONObject jsonResponse = new JSONObject(response);
                JSONObject jsonPerson = jsonResponse.getJSONArray("product").getJSONObject(0);
                return toPersonne(jsonPerson);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        public static void update(Personne pers, ServerRequest sr, ServerCallBack callBack) {
            final String url = "http://www.lsi.metz.supelec.fr/VolleyForAll/update_personne.php";
            Map<String, String> params = new HashMap<>();

            params.put("etunum", "" + pers.getEtunum());
            params.put("nom", "" + pers.getNom());
            params.put("prenom", pers.getPrenom());
            params.put("phoneNb", pers.getTel());
            params.put("email", pers.getEmail());

            sr.requestPost(url, params, callBack);
        }
        public static void update(Personne pers, ServerCallBack callBack) {
            update(pers, sr, callBack);
        }

    }

    public static boolean isSuccess(String str) {
        try {
            JSONObject jsonObject = new JSONObject(str);
            return (jsonObject.getInt("success") == 1);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

    private static Inscrit toInscrit(JSONObject jsonObject, Personne pers) {
        try {
            Log.i("DBM", jsonObject.toString());
            int inscrit_id = jsonObject.getInt("inscrit_id");
            int etunum = jsonObject.getInt("etunum");

            if (etunum != pers.getEtunum()) {
                Exception e = new InvalidKeyException("Etunum is not valid : error when comparing with " + pers.toString());
                e.printStackTrace();
                return null;
            }
            try {
                CDate horaireDeb = new CDate(jsonObject.getString("horaireDeb"));
                CDate horaireFin = new CDate(jsonObject.getString("horaireFin"));
                String materiel = jsonObject.getString("materiel");

                Inscrit inscrit = new Inscrit(inscrit_id, horaireDeb, horaireFin, materiel, pers);
                return inscrit;
            } catch (ParseException e) {
                e.printStackTrace();
            }
        } catch (JSONException e) {
            Log.e("DBM", "Failed to parse Inscrit : " + jsonObject.toString());
            e.printStackTrace();
        }
        return null;
    }
    private static Inscrit toInscrit(String str, Personne pers) {
        try {
            return toInscrit(new JSONObject(str), pers);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static Personne toPersonne(JSONObject jsonObject) {
        try {
            int etunum = jsonObject.getInt("etunum");
            String nom = jsonObject.getString("nom");
            String prenom = jsonObject.getString("prenom");
            String phoneNb = jsonObject.getString("phoneNb");
            String email = jsonObject.getString("email");

            Personne p = new Personne(nom, prenom, etunum, phoneNb, email);
            return p;
        } catch (JSONException e) {
            Log.e("DBM", "Failed to parse Personne : " + jsonObject.toString());
            e.printStackTrace();
        }
        return null;
    }

    private static Personne toPersonne(String str) {
        try {
            return toPersonne(new JSONObject(str));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param nextFunction la fonction next() de l'interface NextFunction sera appelé une fois
     *                     la BDD synchronisée : on met a jour les GlobalVar
     *                     Elle est exécutée lorsque le serveur répond une erreur
     *                     Elle n'est pas exécutée si le serveur ne répond pas
     */
    public static void syncDBAndExecute(NextFunction nextFunction) {

        DBM.PersonneTable.getAll(responsePersonne -> {
            Set<Personne> persSet = DBM.PersonneTable.parseGetAll(responsePersonne);
            Map<Integer, Personne> personneHashMap = new HashMap<>(persSet.size());

            for (Personne pers : persSet) personneHashMap.put(pers.getEtunum(), pers);

            DBM.InscritTable.getAll(responseInscrit -> {
                Set<Inscrit> inscritSet = DBM.InscritTable.parseGetAll(responseInscrit, personneHashMap);
                GlobalVar.AllPersonne = persSet;
                GlobalVar.AllInscrit = inscritSet;
                nextFunction.next();
            });
        });
    }

}
