package com.example.projetcodingweeks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.example.projetcodingweeks.activities.LoginActivity;

import com.example.projetcodingweeks.objects.CDate;
import com.example.projetcodingweeks.objects.Inscrit;
import com.example.projetcodingweeks.objects.Personne;
import com.example.projetcodingweeks.others.DBM;
import com.example.projetcodingweeks.others.GlobalVar;
import com.example.projetcodingweeks.others.ServerRequest;

import java.text.ParseException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBM.InscritTable.sr = new ServerRequest(this); // Ne pas supprimer, permet d'initialiser
        DBM.PersonneTable.sr = new ServerRequest(this); // Ne pas supprimer, permet d'initialiser

        DBM.syncDBAndExecute(() -> {
            Intent toLogin = new Intent();
            toLogin.setClass(getApplicationContext(), LoginActivity.class);
            startActivity(toLogin);
        });

    }

    private void testBDD() {
        Personne lambdaPers = new Personne("Lambda", "Lambda", 1, "", "");
        Personne muPers = new Personne("Mu", "Mu", 2, "", "");
        GlobalVar.CurrentLoggedUser = lambdaPers;

        DBM.PersonneTable.update(lambdaPers, response -> Log.i("Debug", "Updated lambdaPers : " + response));
        DBM.PersonneTable.update(muPers, response -> Log.i("Debug", "Updated muPers : " + response));
        try {
            Inscrit i1 = new Inscrit(1, new CDate("00:00:00 01/01/2020"), new CDate("01:00:00 01/01/2020"), "", lambdaPers);
            Inscrit i2 = new Inscrit(2, new CDate("00:00:00 02/01/2020"), new CDate("01:00:00 02/01/2020"), "", lambdaPers);
            Inscrit i3 = new Inscrit(3, new CDate("00:00:00 03/01/2020"), new CDate("01:00:00 03/01/2020"), "", lambdaPers);
            Inscrit i4 = new Inscrit(4, new CDate("00:00:00 04/01/2020"), new CDate("01:00:00 04/01/2020"), "", lambdaPers);
            Inscrit i5 = new Inscrit(5, new CDate("00:00:00 05/01/2020"), new CDate("01:00:00 05/01/2020"), "", lambdaPers);
            Inscrit i6 = new Inscrit(6, new CDate("00:00:00 06/01/2020"), new CDate("01:00:00 06/01/2020"), "", lambdaPers);
            Inscrit i7 = new Inscrit(7, new CDate("00:00:00 07/01/2020"), new CDate("01:00:00 07/01/2020"), "", lambdaPers);
            Inscrit i8 = new Inscrit(8, new CDate("00:00:00 08/01/2020"), new CDate("01:00:00 08/01/2020"), "", lambdaPers);
            Inscrit i9 = new Inscrit(9, new CDate("00:00:00 09/01/2020"), new CDate("01:00:00 09/01/2020"), "", lambdaPers);

            DBM.InscritTable.update(i1, response -> Log.i("Debug", "Updated i1 : " + response));
            DBM.InscritTable.update(i2, response -> Log.i("Debug", "Updated i2 : " + response));
            DBM.InscritTable.update(i3, response -> Log.i("Debug", "Updated i3 : " + response));
            DBM.InscritTable.update(i4, response -> Log.i("Debug", "Updated i4 : " + response));
            DBM.InscritTable.update(i5, response -> Log.i("Debug", "Updated i5 : " + response));
            DBM.InscritTable.update(i6, response -> Log.i("Debug", "Updated i6 : " + response));
            DBM.InscritTable.update(i7, response -> Log.i("Debug", "Updated i7 : " + response));
            DBM.InscritTable.update(i8, response -> Log.i("Debug", "Updated i8 : " + response));
            DBM.InscritTable.update(i9, response -> Log.i("Debug", "Updated i8 : " + response));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void flushTables() {
        DBM.syncDBAndExecute(() -> {
            for (Inscrit i : GlobalVar.AllInscrit) {
                DBM.InscritTable.delete(i.getInscrit_id(), r -> {});
            }
            try {
                Thread.currentThread().sleep((3000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            for (Personne p : GlobalVar.AllPersonne) {
                DBM.PersonneTable.delete(p.getEtunum(), r -> {});
            }
        });
    }

}
