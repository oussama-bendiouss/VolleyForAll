package com.example.projetcodingweeks.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projetcodingweeks.objects.Inscrit;
import com.example.projetcodingweeks.R;
import com.example.projetcodingweeks.objects.CDate;
import com.example.projetcodingweeks.others.DBM;
import com.example.projetcodingweeks.others.GlobalVar;
import com.google.android.material.textfield.TextInputEditText;

import java.text.ParseException;

public class HeureDispo extends AppCompatActivity {

    private Button buttonBack;
    private Button buttonValider;

    private Button VHoraireDeb;
    private Button VHoraireFin;

    private CDate givenDeb;
    private CDate givenFin;

    private LinearLayout mainLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heure_dispo);

        VHoraireDeb = findViewById(R.id.buttonHoraireDeb);
        VHoraireFin = findViewById(R.id.buttonHoraireFin);

        buttonBack = findViewById(R.id.buttonBack);
        buttonValider = findViewById(R.id.buttonValider);
        mainLayout = findViewById(R.id.l);

        givenDeb = new CDate(CDate.NOW);
        givenFin = new CDate(CDate.TWO_HOUR);

        updateDateDisplay();
    }

    private void updateDateDisplay() {
        VHoraireDeb.setText(givenDeb.getDate());
        VHoraireFin.setText(givenFin.getDate());
    }

    private void PassMenu() {
        Intent versMenu = new Intent();
        versMenu.setClass(getApplicationContext(), MenuActivity.class);
        startActivity(versMenu);
    }

    public void onCliqueDeb(View view) {
        suiteButton(givenDeb);
    }

    public void onCliqueFin(View view) {
        suiteButton(givenFin);
    }

    private void suiteButton(CDate cdate) {
        DatePickerDialog.OnDateSetListener dateListener = (v1, year, month, day) -> {
            String newDate = day + "/" + month + "/" + year;

            TimePickerDialog.OnTimeSetListener timeListener = (v2, hour, min) -> {
                String newTime = hour + ":" + min + ":00";
                try {
                    cdate.setDate(newTime + " " + newDate);
                    updateDateDisplay();
                } catch (ParseException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Erreur lors de l'écriture.", Toast.LENGTH_SHORT).show();
                }
            };
            TimePickerDialog questionTime = new TimePickerDialog(this, timeListener, cdate.getHour(), cdate.getMin(), true);
            questionTime.show();

        };
        DatePickerDialog questionDate = new DatePickerDialog(this, dateListener, cdate.getYear(), cdate.getMonth(), cdate.getDay());
        questionDate.show();

    }

    public void onCliqueBack(View view) {
        PassMenu();
    }

    public void onCliqueValidate(View view) {
        mainLayout.removeAllViewsInLayout();
        boolean found = false;

        for (Inscrit inscrit : GlobalVar.AllInscrit) {
            CDate heure_deb = inscrit.getHoraireDebut();
            CDate heure_fin = inscrit.getHoraireFin();
            boolean notDebAfterFin = ! heure_deb.getDateObject().after(givenFin.getDateObject());
            boolean notFinBeforeDeb = ! heure_fin.getDateObject().before(givenDeb.getDateObject());
            // Test if intersection is not null
            if (notFinBeforeDeb && notDebAfterFin) {
                found = true;
                TextView affichage = new TextView(this);
                affichage.setText(inscrit.getAffichage());
                mainLayout.addView(affichage);
            }
        }
        
        if (!found)
            Toast.makeText(this, "Pas d'activités dans ces horaires", Toast.LENGTH_SHORT).show();

    }

}