package com.example.projetcodingweeks.activities.inscritactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projetcodingweeks.objects.CDate;
import com.example.projetcodingweeks.others.DBM;
import com.example.projetcodingweeks.objects.Inscrit;
import com.example.projetcodingweeks.activities.MenuActivity;
import com.example.projetcodingweeks.R;
import com.example.projetcodingweeks.others.ServerCallBack;

import java.text.ParseException;

public class InscritActivityModifier extends AppCompatActivity {

    private Inscrit inscriptionUtilisateur;

    private Button HoraireDebut;
    private Button HoraireFin;
    private CheckBox hasBall;

    private CDate newDateDeb;
    private CDate newDateFin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscrit_modifier);

        Intent toHere = getIntent();
        inscriptionUtilisateur = (Inscrit) toHere.getSerializableExtra("Inscription");

        HoraireDebut = findViewById(R.id.buttonHoraireDebut);
        HoraireFin = findViewById(R.id.buttonHoraireFin);
        hasBall = findViewById(R.id.hasBall);

        newDateDeb = inscriptionUtilisateur.getHoraireDebut();
        newDateFin = inscriptionUtilisateur.getHoraireFin();

        HoraireDebut.setText(inscriptionUtilisateur.getHoraireDebut().getDate());
        HoraireFin.setText(inscriptionUtilisateur.getHoraireFin().getDate());
        updateDateDisplay();

    }

    public void modifyDeb(View view) {
        modifyDateAndTime(newDateDeb);
    }

    public void modifyFin(View view) {
        modifyDateAndTime(newDateFin);
    }

    private void modifyDateAndTime(CDate cdate) {
        DatePickerDialog.OnDateSetListener dateListener = (v1, year, month, day) -> {
            String newDate = day + "/" + month + "/" + year;


            TimePickerDialog.OnTimeSetListener timeListener = (v2, hour, min) -> {
                String newTime = hour + ":" + min + ":00";
                try {
                    cdate.setDate(newTime + " " + newDate);
                    DBM.InscritTable.update(inscriptionUtilisateur, response -> {
                        if (DBM.isSuccess(response)) {
                            updateDateDisplay();
                            Toast.makeText(this, "La mise a jour a bien été faite.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Une erreur est apparue lors de la mise à jour.", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (ParseException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Erreur lors de l'écriture.", Toast.LENGTH_SHORT).show();
                }
            };
            TimePickerDialog questionTime = new TimePickerDialog(this, timeListener, cdate.getHour(), cdate.getMin(), true);
            questionTime.show();

        };
        DatePickerDialog questionDate = new DatePickerDialog(this, dateListener, cdate.getYear(), cdate.getMonth(), cdate.getDay());
        questionDate.show();
    }

    private void updateDateDisplay() {
        HoraireDebut.setText(newDateDeb.getDate());
        HoraireFin.setText(newDateFin.getDate());
    }

    public void cliqueRetour(View view) {
        PassMenu();
    }

    public void clickValidate(View view) {
        inscriptionUtilisateur.setMateriel("rien");
        if (hasBall.isChecked())
           inscriptionUtilisateur.setMateriel("Ballon");

        inscriptionUtilisateur.setHoraireDebut(newDateDeb);
        inscriptionUtilisateur.setHoraireFin(newDateFin);

        //on rajoute les horaires et le materiel dans la base de données
        DBM.InscritTable.update(inscriptionUtilisateur, this::onResponseModify);
    }

    private void onResponseModify(String response) {
        if (DBM.isSuccess(response)) {
            Toast.makeText(this, "L'activité a été modifiée avec succès.", Toast.LENGTH_SHORT).show();
            // On synchronise la BDD locale
            DBM.syncDBAndExecute(() ->{});
        } else {
            Toast.makeText(this, "Une erreur est apparue lors de la modification de l'activité.", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickDelete(View view) {
        DBM.InscritTable.delete(inscriptionUtilisateur.getInscrit_id(), response -> {
            if (DBM.isSuccess(response)) {
                Toast.makeText(InscritActivityModifier.this, "L'inscription a été supprimée.", Toast.LENGTH_SHORT).show();
                DBM.syncDBAndExecute(() -> {
                    Toast.makeText(InscritActivityModifier.this, "Synchronisation réussie", Toast.LENGTH_SHORT).show();
                    PassMenu();
                });
            } else {
                Toast.makeText(InscritActivityModifier.this, "Erreur.", Toast.LENGTH_SHORT).show();
                Log.e("DeleteInscritError", response);
            }
        });
    }

    private void PassMenu() {
        Intent versMenu = new Intent();
        versMenu.setClass(getApplicationContext(), MenuActivity.class);
        startActivity(versMenu);
    }
}