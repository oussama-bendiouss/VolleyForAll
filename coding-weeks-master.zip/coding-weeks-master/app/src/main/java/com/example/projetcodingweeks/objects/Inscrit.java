package com.example.projetcodingweeks.objects;

import java.io.Serializable;

public class Inscrit implements Serializable {
    private int inscrit_id;
    private CDate HoraireDebut;
    private CDate HoraireFin;
    private String Materiel;
    private Personne personneConcerne;

    public Inscrit(CDate HoraireDebut, CDate HoraireFin, String Materiel, Personne personneConcerne) {
        this.HoraireDebut = HoraireDebut;
        this.HoraireFin = HoraireFin;
        this.Materiel = Materiel;
        this.personneConcerne = personneConcerne;
    }
    public Inscrit(int inscrit_id, CDate HoraireDebut, CDate HoraireFin, String Materiel, Personne personneConcerne) {
        this.inscrit_id = inscrit_id;
        this.HoraireDebut = HoraireDebut;
        this.HoraireFin = HoraireFin;
        this.Materiel = Materiel;
        this.personneConcerne = personneConcerne;
    }

    public CDate getHoraireDebut () {return HoraireDebut;}

    public void setHoraireDebut (CDate HoraireDebut) {this.HoraireDebut = HoraireDebut;}

    public CDate getHoraireFin() { return HoraireFin;}

    public void setHoraireFin(CDate HoraireFin) { this.HoraireFin = HoraireFin;}

    public String getMateriel () {return Materiel;}

    public void setMateriel (String Materiel) {this.Materiel = Materiel;}

    public Personne getPersonneConcerne () {return personneConcerne;}

    public int getInscrit_id() {return inscrit_id;}

    public void setInscrit_id(int inscrit_id) {this.inscrit_id = inscrit_id;}

    public String getAffichage() {
        String str = "Début : " + HoraireDebut.getDate() + "\n";
        str += "Fin : " + HoraireFin.getDate() + "\n";
        str += "Personne : " + personneConcerne.getPrenom() + " " + personneConcerne.getNom() + "\n";
        str += "Matériel : " + Materiel;
        return str;
    }
}
