package com.example.projetcodingweeks.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projetcodingweeks.objects.Personne;
import com.example.projetcodingweeks.R;
import com.example.projetcodingweeks.others.DBM;
import com.example.projetcodingweeks.others.GlobalVar;
import com.example.projetcodingweeks.others.ServerCallBack;

public class Notification_Activity extends AppCompatActivity {

    private EditText editTextMail;
    private EditText editTextTel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        //récupération des liens
        editTextMail = findViewById(R.id.editTextMail);
        editTextTel = findViewById(R.id.editTextTel);

        TextView tvPrenom = findViewById(R.id.textViewPrenom);
        tvPrenom.setText(GlobalVar.CurrentLoggedUser.getPrenom());

        TextView tvNom = findViewById(R.id.textViewNom);
        tvNom.setText(GlobalVar.CurrentLoggedUser.getNom());

        TextView tvEtunum = findViewById(R.id.textViewEtunum);
        tvEtunum.setText("" + GlobalVar.CurrentLoggedUser.getEtunum());

    }

    public void OkClique(View view) {
        //On récupère les info qui ont été rentrées pour les ajouter à la base de données
        if (editTextMail.getText().toString() != "")
            GlobalVar.CurrentLoggedUser.setEmail(editTextMail.getText().toString());
        if (editTextTel.getText().toString() != "")
            GlobalVar.CurrentLoggedUser.setTel(editTextTel.getText().toString());

            //On envoit ensuite ces modifications à la base de données
        DBM.PersonneTable.update(GlobalVar.CurrentLoggedUser, new ServerCallBack() {
            @Override
            public void onResponse(String response) {
                if (DBM.isSuccess(response)) {
                    Toast.makeText(Notification_Activity.this, "Les modifications ont été enregistrées.", Toast.LENGTH_SHORT).show();
                    PassMenu();
                } else {
                    Toast.makeText(Notification_Activity.this, "Une erreur est survenue.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void BackClique(View view) {
        //on retourne à MenuActivity
        PassMenu();
    }


    //pour passer à MenuActivity
    private void PassMenu() {
        Intent versMenu = new Intent();
        versMenu.setClass(getApplicationContext(), MenuActivity.class);
        startActivity(versMenu);
    }
}