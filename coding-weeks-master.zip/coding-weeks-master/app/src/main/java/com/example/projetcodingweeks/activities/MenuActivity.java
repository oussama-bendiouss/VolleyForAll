package com.example.projetcodingweeks.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.projetcodingweeks.R;
import com.example.projetcodingweeks.activities.inscritactivity.InscritActivityAjout;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void HoraireClique(View view) {
        PassSearchHoraire();
    }

    public void InscriptionClique(View view) {
        //vers MesInscriptionActivity, pour gérer ses enciennes inscriptions
        PassMesInscriptions();
    }

    public void PreferencesClique(View view) {
        //vers NotificationActivity
        PassPreference();
    }

    public void InscrireClique(View view) {
        //vers InscritActivityAjout, pour s'inscrire sur de nouveaux créneaux
        PassInscritAjout();
    }


    //pour passer vers HeureDispoActivity
    private void PassSearchHoraire() {
        Intent versHoraire = new Intent();
        versHoraire.setClass(getApplicationContext(), HeureDispo.class);
        startActivity(versHoraire);
    }

    //pour passe à MesInscriptionsActivity
    private void PassMesInscriptions() {
        Intent versMesInscriptions = new Intent();
        versMesInscriptions.setClass(getApplicationContext(), MesInscriptionsActivity.class);
        startActivity(versMesInscriptions);
    }

    //pour passer à Notification_Activity qui correspond au préférences
    private void PassPreference() {
        Intent versNotif = new Intent();
        versNotif.setClass(getApplicationContext(), Notification_Activity.class);
        startActivity(versNotif);
    }

    //pour passer à InscritActivityAjout
    private void PassInscritAjout() {
        Intent versInscritAjout = new Intent();
        versInscritAjout.setClass(getApplicationContext(), InscritActivityAjout.class);
        startActivity(versInscritAjout);
    }
}

