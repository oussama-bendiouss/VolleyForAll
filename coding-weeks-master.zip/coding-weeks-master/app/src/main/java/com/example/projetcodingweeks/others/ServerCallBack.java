package com.example.projetcodingweeks.others;

public interface ServerCallBack {
    void onResponse(String response);
}
